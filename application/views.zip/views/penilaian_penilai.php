<!-- Batas Tanda -->
<div class="logo-pro">
  <a href="index.html"><img class="main-logo" align="center" src="img/paskibraka.jpeg" alt="" /></a>
</div>

<div class="row">
  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div class="sparkline12-list">
      <div class="sparkline12-hd">
        <div class="main-sparkline12-hd">
          <h1>Penilaian Peserta</h1>
        </div>
      </div>
      <div class="sparkline12-graph">
        <div class="basic-login-form-ad">
          <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
              <div class="all-form-element-inner">

                <form action="<?php echo base_url() ?>Admin/insert_nilai_tim_penilai" method="post">

                  <div class="form-group-inner">
                    <div class="row">
                      <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                        <label class="login2 pull-right pull-right-pro">Kesehatan</label>
                      </div>
                      <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
                        <div class="form-select-list">
                          <select class="form-control custom-select-value" name="kesehatan">
                            <option value="100">10 Aspek Kesehatan Baik</option>
                            <option value="90">9 Aspek Kesehatan Baik</option>
                            <option value="80">8 Aspek Kesehatan Baik</option>
                            <option value="70">7 Aspek Kesehatan Baik</option>
                            <option value="60">6 Aspek Kesehatan Baik</option>
                            <option value="50">5 Aspek Kesehatan Baik</option>
                            <option value="40">4 Aspek Kesehatan Baik</option>
                            <option value="30">3 Aspek Kesehatan Baik</option>
                            <option value="20">2 Aspek Kesehatan Baik</option>
                            <option value="10">1 Aspek Kesehatan Baik</option>

                          </select>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="form-group-inner">
                    <div class="row">
                      <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                        <label class="login2 pull-right pull-right-pro">Kebugaran Jasmani</label>
                      </div>
                      <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
                        <div class="form-select-list">
                          <select class="form-control custom-select-value" name="jasmani">
                            <option value="100">Sangat Baik</option>
                            <option value="80">Baik</option>
                            <option value="60">Cukup Baik</option>
                            <option value="40">Tidak Baik</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>



                  <div class="form-group-inner">
                    <div class="row">
                      <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                        <label class="login2 pull-right pull-right-pro">Postur Tubuh</label>
                      </div>
                      <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
                        <div class="form-select-list">
                          <select class="form-control custom-select-value" name="postur">
                            <option value="100">Sangat Baik</option>
                            <option value="80">Baik</option>
                            <option value="60">Cukup Baik</option>
                            <option value="40">Tidak Baik</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="form-group-inner">
                    <div class="login-btn-inner">
                      <div class="row">
                        <div class="col-lg-3"></div>
                        <div class="col-lg-9">
                          <div class="login-horizental cancel-wp pull-left">
                            <button class="btn btn-white" type="submit">Batal</button>
                            <button class="btn btn-sm btn-primary login-submit-cs" type="submit">Kirim</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <input type="text" value="<?php echo $nisn; ?>" name="nisn" hidden>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- End Of Tanda -->