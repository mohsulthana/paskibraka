    <!-- Batas Tanda -->
    <a href="<?php echo base_url() ?>Admin/home"><br>    <img class="main-logo" src="<?php echo base_url() ?>img/paskibraka.jpeg" style="display: block; margin: 50px auto;" alt="" /></a>

    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
      <div class="sparkline12-list">
        <div class="sparkline12-hd">
          <div class="main-sparkline12-hd">
            <h1>Paskibraka Sumatera Selatan</h1>
          </div>
        </div>
        <p> Upacara memperingati HUT RI setiap tanggal 17 Agustus adalah momentum bagi Pemuda untuk berkarya, menatap
          masa depan Indonesia
          dalam mengisi Keindahan dan memperkuat kemegahan rasa kemerdekaan. <br> Pasukan Pengibar Bendera Pusaka
          (Paskibraka) Sumatera Selatan
          terdiri dari kelompok 8, kelompok 17 dan kelompok pasukan 45 yang berasal dari TNI Polri.<br> Peserta
          Paskibraka Sumatera Selatan berjumlah 50
          orang yang terdiri dari kelompok Merah 25 orang sebagai TIM Pengibar Bendera merah Putih dan Kelompok Putih
          berjumlah 25 orang sebagai TIM
          penurunan Bendera Merah Putih. <br> Sebelum menjadi anggota Paskibraka peserta tentunya dilakukan seleksi
          mulai dari tingkat sekolah sampai
          tingkat Nasional. </p>
      </div>
    </div>
    </div>

    <!-- End Of Tanda -->