

								<!-- Batas Tanda -->
								<div class="logo-pro">
											<a href="index.html"><img class="main-logo" align="center" src="img/paskibraka.jpeg" alt="" /></a>
								</div>

								<div class="row">
																				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
																								<div class="sparkline12-list">
																												<div class="sparkline12-hd">
																																<div class="main-sparkline12-hd">
																																				<h1>Input User Baru</h1>
																																</div>
																												</div>
																												<div class="sparkline12-graph">
																																<div class="basic-login-form-ad">
																																				<div class="row">
																																								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
																																												<div class="all-form-element-inner">
																																													
																																																<form action="<?php echo base_url() ?>Admin/insert_user_baru" method="post">
																																																				
																																																					<div class="form-group-inner">
																																																								<div class="row">
																																																												<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
																																																																<label class="login2 pull-right pull-right-pro">ID_User</label>
																																																												</div>
																																																												<div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
																																																																<input type="text" name="nisn" class="form-control" />
																																																												</div>
																																																								</div>
																																																				</div>

																																																				<div class="form-group-inner">
																																																								<div class="row">
																																																												<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
																																																																<label class="login2 pull-right pull-right-pro">Nama Lengkap</label>
																																																												</div>
																																																												<div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
																																																																<input type="text" name="namalengkap" class="form-control" />
																																																												</div>
																																																								</div>
																																																				</div>

																																																			<div class="form-group-inner">
																																																								<div class="row">
																																																												<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
																																																																<label class="login2 pull-right pull-right-pro">Username</label>
																																																												</div>
																																																												<div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
																																																																<input type="text" name="nama" class="form-control" />
																																																												</div>
																																																								</div>
																																																				</div>

																																																				<div class="form-group-inner">
																																																								<div class="row">
																																																												<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
																																																																<label class="login2 pull-right pull-right-pro">Password</label>
																																																												</div>
																																																												<div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
																																																																<input type="text" name="password" class="form-control" />
																																																												</div>
																																																								</div>
																																																				</div>

																																																						<div class="form-group-inner">
																																																								<div class="row">
																																																											
																																																												<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
																																																																<label class="login2 pull-right pull-right-pro">Status</label>
																																																												</div>
																																																												<div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
																																																																<div class="form-select-list">
																																																																				<select class="form-control custom-select-value" name="status">
																																																																				<option value="1">Peserta</option>
																																																																				<option value="2">Admin Dispora</option>
																																																																				<option value="3">Pimpinan</option>
																																																																				<option value="4">Admin Sistem</option>
																																																																				<option value="5">Team Penilai</option>
																																																																			</select>
																																																																</div>
																																																												</div>
																																																								</div>
																																																				</div>

																																																				

																																																				<div class="form-group-inner">
																																																								<div class="login-btn-inner">
																																																												<div class="row">
																																																																<div class="col-lg-3"></div>
																																																																<div class="col-lg-9">
																																																																				<div class="login-horizental cancel-wp pull-left">
																																																																								<button class="btn btn-white" type="submit">Batal</button>
																																																																								<button class="btn btn-sm btn-primary login-submit-cs" type="submit">Kirim</button>
																																																																				</div>
																																																																</div>
																																																												</div>
																																																								</div>
																																																				</div>
																																																			
																																																</form>
																																												</div>
																																								</div>
																																				</div>
																																</div>
																												</div>
																								</div>
																				</div>
																</div>

								<!-- End Of Tanda -->

					