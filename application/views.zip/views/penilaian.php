
							<!-- Batas Tanda -->
								<div class="logo-pro">
											<a href="index.html"><img class="main-logo" align="center" src="img/paskibraka.jpeg" alt="" /></a>
								</div>

								<div class="row">
																				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
																								<div class="sparkline12-list">
																												<div class="sparkline12-hd">
																																<div class="main-sparkline12-hd">
																																				<h1>Penilaian Peserta</h1>
																																</div>
																												</div>
																												<div class="sparkline12-graph">
																																<div class="basic-login-form-ad">
																																				<div class="row">
																																								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
																																												<div class="all-form-element-inner">
																																													
																																																<form action="<?php echo base_url() ?>/Admin/insert_nilai_admin" method="post">
																																																				
																																																					<div class="form-group-inner">
																																																								<div class="row">
																																																												<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
																																																																<label class="login2 pull-right pull-right-pro">Tes Tertulis</label>
																																																												</div>
																																																												<div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
																																																																<input type="integer" name="tertulis" class="form-control" />
																																																												</div>
																																																								</div>
																																																				</div>

																																																				<div class="form-group-inner">
																																																								<div class="row">
																																																											
																																																												<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
																																																																<label class="login2 pull-right pull-right-pro">Attitude</label>
																																																												</div>
																																																												<div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
																																																																<div class="form-select-list">
																																																																				<select class="form-control custom-select-value" name="attitude">
																																																																				<option value="100">Sangat Baik</option>
																																																																				<option value="80">Baik</option>
																																																																				<option value="60">Cukup Baik</option>
																																																																				<option value="40">Tidak Baik</option>
																																																																			</select>
																																																																</div>
																																																												</div>
																																																								</div>
																																																				</div>

																																																				<div class="form-group-inner">
																																																								<div class="row">
																																																											
																																																												<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
																																																																<label class="login2 pull-right pull-right-pro">Karakter</label>
																																																												</div>
																																																												<div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
																																																																<div class="form-select-list">
																																																																				<select class="form-control custom-select-value" name="karakter">
																																																																				<option value="100">Sangat Baik</option>
																																																																				<option value="80">Baik</option>
																																																																				<option value="60">Cukup Baik</option>
																																																																				<option value="40">Tidak Baik</option>
																																																																			</select>
																																																																</div>
																																																												</div>
																																																								</div>
																																																				</div>

																																																				<div class="form-group-inner">
																																																								<div class="row">
																																																											
																																																												<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
																																																																<label class="login2 pull-right pull-right-pro">Antusiasme</label>
																																																												</div>
																																																												<div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
																																																																<div class="form-select-list">
																																																																				<select class="form-control custom-select-value" name="antusiasme">
																																																																				<option value="100">Sangat Baik</option>
																																																																				<option value="80">Baik</option>
																																																																				<option value="60">Cukup Baik</option>
																																																																				<option value="40">Tidak Baik</option>
																																																																			</select>
																																																																</div>
																																																												</div>
																																																								</div>
																																																				</div>

																																																				<div class="form-group-inner">
																																																								<div class="row">
																																																											
																																																												<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
																																																																<label class="login2 pull-right pull-right-pro">Pengalaman</label>
																																																												</div>
																																																												<div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
																																																																<div class="form-select-list">
																																																																				<select class="form-control custom-select-value" name="pengalaman">
																																																																				<option value="100">Sangat Baik</option>
																																																																				<option value="80">Baik</option>
																																																																				<option value="60">Cukup Baik</option>
																																																																				<option value="40">Tidak Baik</option>
																																																																			</select>
																																																																</div>
																																																												</div>
																																																								</div>
																																																				</div>

																																																				<div class="form-group-inner">
																																																								<div class="row">
																																																											
																																																												<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
																																																																<label class="login2 pull-right pull-right-pro">Komunikasi</label>
																																																												</div>
																																																												<div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
																																																																<div class="form-select-list">
																																																																				<select class="form-control custom-select-value" name="komunikasi">
																																																																				<option value="100">Sangat Baik</option>
																																																																				<option value="80">Baik</option>
																																																																				<option value="60">Cukup Baik</option>
																																																																				<option value="40">Tidak Baik</option>
																																																																			</select>
																																																																</div>
																																																												</div>
																																																								</div>
																																																				</div>

																																																				

																																																				<div class="form-group-inner">
																																																								<div class="login-btn-inner">
																																																												<div class="row">
																																																																<div class="col-lg-3"></div>
																																																																<div class="col-lg-9">
																																																																				<div class="login-horizental cancel-wp pull-left">
																																																																								<button class="btn btn-white" type="submit">Batal</button>
																																																																								<button class="btn btn-sm btn-primary login-submit-cs" type="submit">Kirim</button>
																																																																				</div>
																																																																</div>
																																																												</div>
																																																								</div>
																																																				</div>


																																																				
																																																				<input type="text" value="<?php echo $nisn; ?>" name="nisn" hidden>
																																																</form>
																																												</div>
																																								</div>
																																				</div>
																																</div>
																												</div>
																								</div>
																				</div>
																</div>

								<!-- End Of Tanda -->

	

    <!-- Batas Tanda -->
   