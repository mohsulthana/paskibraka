


								<!-- Batas Tanda -->
								<div class="logo-pro">
											<a href="index.html"><img class="main-logo" align="center" src="img/paskibraka.jpeg" alt="" /></a>
								</div>

								<div class="row">
																				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
																								<div class="sparkline12-list">
																												<div class="sparkline12-hd">
																																<div class="main-sparkline12-hd">
																																				<h1>UPDATE KRITERIA</h1>
																																</div>
																												</div>
																												<div class="sparkline12-graph">
																																<div class="basic-login-form-ad">
																																				<div class="row">
																																								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
																																												<div class="all-form-element-inner">
																																										
																																																<form action="<?php echo base_url() ?>Admin/insert_bobot" method="post">
																																																				
																																																					<div class="form-group-inner">
																																																								<div class="row">
																																																												<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
																																																																<label class="login2 pull-right pull-right-pro">Nama Kriteria</label>
																																																												</div>
																																																												<div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
																																																																<input type="text" name="nama" class="form-control" />
																																																												</div>
																																																								</div>

																																																									<div class="row">
																																																												<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
																																																																<label class="login2 pull-right pull-right-pro">Bobot Kriteria</label>
																																																												</div>
																																																												<div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
																																																																<input type="text" name="bobot" class="form-control" />
																																																												</div>
																																																								</div>
																																																				</div>

																																																			
																																																				<div class="form-group-inner">
																																																								<div class="login-btn-inner">
																																																												<div class="row">
																																																																<div class="col-lg-3"></div>
																																																																<div class="col-lg-9">
																																																																				<div class="login-horizental cancel-wp pull-left">
																																																																								<button class="btn btn-white" type="submit">Batal</button>
																																																																								<button class="btn btn-sm btn-primary login-submit-cs" type="submit">Kirim</button>
																																																																				</div>
																																																																</div>
																																																												</div>
																																																								</div>
																																																				</div>
																																																				<input type="text" value="<?php echo $id_bobot; ?>" name="id_bobot" hidden>
																																																</form>
																																												</div>
																																								</div>
																																				</div>
																																</div>
																												</div>
																								</div>
																				</div>
																</div>

								<!-- End Of Tanda -->

					