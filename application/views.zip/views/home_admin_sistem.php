    <!-- Batas Tanda -->
    
    <a href="<?php echo base_url() ?>Admin/home"><br>    <img  width="500" height="400" class="main-logo" src="<?php echo base_url() ?>img/foto6.jpeg" style="display: block; margin: 30px auto;" alt="" /></a>
    
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
      <div class="sparkline12-list">
        <div class="sparkline12-hd">
          <div class="main-sparkline12-hd">
            
          </div>
        </div>
        <h1 align="center">Paskibraka Sumatera Selatan</h1>
          <p >Paskibraka merupakan Pasukan Pengibaran Bendera Pusaka. Dalam menjadi anggota paskibraka, harus melalui beberapa tahap seleksi guna mencari potensi-potensi terbaik dari seluruh penjuru negeri, dari tingkat kabupaten/kota, provinsi hingga nasional. Seleksi paskibraka Provinsi Sumatera Selatan adalah seleksi yang dilaksanakan dari tingkat sekolah sampai dengan tingkat Nasional dengan materi seleksi yang meiputi tes tertulis, kebugaran jasmani, kesehatan, baris berbaris dan penilaian lainnya.  <br><br>
            <img width="300" height="200" src="<?= asset_url();?>landing/img/foto5.jpeg" style="display: block; margin: 10px auto;" alt=""><br><br>
          Seleksi paskibraka diikuti 17 Kabupaten/Kota. Kegiatan-kegiatan yang diadakan untuk peserta  anggota Paskibraka sangat beragam, mulai dari pengenalan kepribadian dengan renungan jiwa, pengukuhan secara resmi, pelatihan dan lainnya. </p>
      </div>
    </div>
    </div>